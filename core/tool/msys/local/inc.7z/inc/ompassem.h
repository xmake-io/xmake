/***
*ompassem.h - Libraries Assembly information
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       This file has information about Libraries Assembly version.
*
*
****/

#pragma once

#ifndef _VC_ASSEMBLY_PUBLICKEYTOKEN
#define _VC_ASSEMBLY_PUBLICKEYTOKEN "1fc8b3b9a1e18e3b"
#endif

#ifndef __OPENMP_ASSEMBLY_VERSION
#define __OPENMP_ASSEMBLY_VERSION "9.0.21022.8"
#endif

#ifndef __OPENMP_ASSEMBLY_NAME_PREFIX
#define __OPENMP_ASSEMBLY_NAME_PREFIX "Microsoft.VC90"
#endif
